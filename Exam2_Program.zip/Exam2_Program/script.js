window.onload = init;
function init(){
    var button = document.getElementById("button");
    button.onclick = createTable;

    function createTable(){
        var first_input = document.getElementById("first_name");
        var last_input = document.getElementById("last_name");
        var number_input = document.getElementById("numbers");

        var first_name =  first_input.value;
        var last_name = last_input.value;
        var numbers = number_input.value;

        var table = document.getElementById("table");
        
        count = 1;

        for(var i = 0; i < numbers; i++){
            var user_num = Math.floor(Math.random() * (999 - 100)) + 100;
            var pin = Math.floor(Math.random() * (9999 - 1111) + 1111);

            if(i < 1){
                var tr = document.createElement("tr");

                var th_1 = document.createElement("th");
                var seq_num = document.createTextNode("seq");
                th_1.appendChild(seq_num)

                var th_2 = document.createElement("th");
                var user_name = document.createTextNode("Username");
                th_2.appendChild(user_name);

                var th_3 = document.createElement("th");
                var email = document.createTextNode("Email");
                th_3.appendChild(email);

                var th_4 = document.createElement("th");
                var user_pin = document.createTextNode("PIN");
                th_4.appendChild(user_pin);

                tr.appendChild(th_1);
                tr.appendChild(th_2);
                tr.appendChild(th_3);
                tr.appendChild(th_4);

                table.appendChild(tr);
            }

            var tr = document.createElement("tr");

            var td_1 = document.createElement("td");
            var seq_num = document.createTextNode(count.toString());
            td_1.appendChild(seq_num);

            var td_2 = document.createElement("td");
            var user_name = document.createTextNode(first_name + last_name + user_num.toString());
            td_2.appendChild(user_name);

            var td_3 = document.createElement("td");
            var email = document.createTextNode(first_name + last_name + user_num.toString() + "@jg.edu");
            td_3.appendChild(email);

            var td_4 = document.createElement("td");
            var user_pin = document.createTextNode(pin.toString());
            td_4.appendChild(user_pin);

            tr.appendChild(td_1);
            tr.appendChild(td_2);
            tr.appendChild(td_3);
            tr.appendChild(td_4);

            table.appendChild(tr);

            count++;
        }
    }
}