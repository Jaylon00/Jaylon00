window.onload = init;

var data;
var lat_var;
var long_var;

function init(){
    var url = "http://cs.sfasu.edu/kkahler/Data1.json/?callback=go";
    var newScript = document.createElement("script");
    newScript.setAttribute("src",url);
    newScript.setAttribute("id","jsonp");

    if(navigator.geolocation)
        navigator.geolocation.getCurrentPosition(getCoords);
    else
        alert("no geolocation support");

    function getCoords(position){
        var lat1 = position.coords.latitude;
        var long2 = position.coords.longitude;

        lat_var = lat1;
        long_var = long2;
    }

    var first_button = document.getElementById("button1");
    first_button.onclick = colorChange;

    var sec_button = document.getElementById("button2");
    sec_button.onclick = capitol;

    var third_button = document.getElementById("button3");
    third_button.onclick = myLocation;
}



function go(myData){
    data = JSON.parse(myData);
}

function colorChange(){
    for (var i = 0; i < data.length; i++){
        simplemaps_usmap_mapdata.state_specific[data[i].state].color = data[i].color;	
		simplemaps_usmap_mapdata.state_specific[data[i].state].description = data[i].votes;
    }

    simplemaps_usmap.refresh();
}
function capitol(){
    var capitol = {
        name : "Washington, D.C",
        lat : 38.892443903676075,
        long : -77.0114946431406,
        description: "US Capitol",
        color: "Green",
        type: "star", 
        size: "default"
    };

    simplemaps_usmap_mapdata.locations["0"] = capitol;
    simplemaps_usmap.refresh();
}

function myLocation(){
    var current = {
        name : "My location",
        lat : lat_var,
        long: long_var,
        description: "My location",
        color: "red",
        type: "heart",
        size: "default"
    };
    simplemaps_usmap_mapdata.locations["1"] = current;
    simplemaps_usmap.refresh();
}