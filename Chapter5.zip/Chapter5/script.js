window.onload = init;

function init(){

    var map;
/*
    if (location.protocol !== 'https:') {
        location.replace(`https:${location.href.substring(location.protocol.length)}`);
    }
*/
    if(navigator.geolocation){
        navigator.geolocation.getCurrentPosition(findCoords);
        navigator.geolocation.getCurrentPosition(displayLocation);
    }
    else{
        alert("no geolocation found");
    }
        
    function findCoords(position){
        var lat = position.coords.latitude;
        var long = position.coords.longitude;
        var div = document.getElementById("coords");
        div.innerHTML = "I am at "+ lat + " and Longitude: "+ long +" , but I wish I was in Japan."

        showMap();
    }

    var myCoords = {
        mylat: position.coords.latitude,
        mylong: position.coords.longitude
    }

    function displayLocation(position) {
        var latitude = position.coords.latitude;
        var longitude = position.coords.longitude;
        var div = document.getElementById("location");
        div.innerHTML = "You are at Latitude: " + latitude + ", Longitude: " + longitude;
        var km = computeDistance(position.coords, myCoords);
        var distance = document.getElementById("distance");
        distance.innerHTML = "You are " + km + " km from my location";

        showMap(position.coords)
    }

    function showMap(){
        var googleLatAndLong = new google.maps.LatLng(36.2048,138.2529);
        var options = {
            zoom: 15,
            center: googleLatAndLong,
            mapID: google.maps.MapTypeId.HYBRID
        };

        var div = document.getElementById("map");

        map = new google.maps.Map(div, options);

        marker(map,googleLatAndLong);
    }

    function marker(map, latlong){
        options = {
            position: latlong,
            map: map,
            clickable: true
        };
        var mark = new google.maps.Marker(options);  
    }
}