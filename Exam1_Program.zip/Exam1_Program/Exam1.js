window.onload =init;

function init(){
    var numbers = document.getElementById("numbers");
    var result=" ";
    for(var x = 0; x < 10; x++){
        var num_1 = (Math.floor(Math.random() * (101)) +1);
        var num_2 = (Math.floor(Math.random() * (101)) +1);

        result = result +"My two random  numbers are: "+num_1+" and "+num_2+".";

        if(num_1 > num_2)
            result = result + " "+num_1+" is bigger </br>";
        else if(num_2 > num_1)
            result = result + " "+num_2+" is bigger </br>";
        else
            result = result +" they are equal</br>";
    }
    numbers.innerHTML = result;

    var pt_2 = document.getElementById("second_part");
    var r_num = (Math.floor(Math.random() * (101)) +1);

    var myArray = new Array();
    myArray[0] = r_num;
    myArray[1] = document.getElementById("r_num");


    pt_2.innerHTML = myArray[0] + myArray[1];
}