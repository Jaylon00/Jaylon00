window.onload = init;

function init (){
    var url = "myJSON.JSON";
    var req = new XMLHttpRequest();

    req.open("GET",url);
    req.onload = function(){
        if(req.status == 200){
            update(req.responseText);
        }
    };
    req.send(null);

    function update(responseText){
        var x  = Math.floor(Math.random * (0 - 4)) + 0;

        var pic = document.getElementById("pic");
        var info = JSON.parse(responseText);

        pic.innerHTML = info[0][x];
    }

}