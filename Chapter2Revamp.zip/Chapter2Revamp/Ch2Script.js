window.onload = init;

function init(){
    var sharesArray = new Array(30);
    var max = 10000;
    var min = 7000;
    var myDiv = document.getElementById("sharesList");
    var myUL = document.createElement("ul");

    for(var i = 0; i <= sharesArray.length; i++){
        var li = document.createElement("li");
        var numbers = Math.floor(Math.random() * (max-min)) + min;
        var day = i;

        if(i % 7 == 0){
            li.innerHTML = "Day: "+ day +" -->"+" Closed";
        }
        else{
            if(numbers >= 8500){
                li.innerHTML ="Day: "+ day +" -->"+" Share "+ i +" , Traded: "+ numbers + " , Above 8500";
            }
            
            if(numbers <= 8500){
                li.innerHTML ="Day: "+ day +" -->"+" Share "+ i +" , Traded: "+ numbers +" , Below 8500";
                
            }   
        }

        myUL.appendChild(li);
        
    } 
    myDiv.appendChild(myUL);
}