//Jaylon Garza
window.onload = init;

function init(){
    var button = document.getElementById("magic")
    button.onclick = clickButton;

    var resetButton = document.getElementById("reset");
    resetButton.onclick = formReset;
}

function clickButton(){
    var term_input = document.getElementById("term");
    var def_input =document.getElementById("definition");

    var term = term_input.value;
    var define = def_input.value;

    var dt = document.createElement("dt");
    var dd = document.createElement("dd");

    dt.innerHTML = term;
    dd.innerHTML = define;

    var dl = document.getElementById("dl");

    dl.appendChild(dt);
    dl.appendChild(dd);
}

function formReset(){
    document.getElementById("term").value = "Term";
    document.getElementById("definition").value = "Definition"; 
}