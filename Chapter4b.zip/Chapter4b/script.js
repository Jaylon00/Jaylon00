window.onload = init;

function init(){
    var player_button = document.getElementById("player");
    player_button.onclick = addPlayer;

    var show_button = document.getElementById("show");
    show_button.onclick = display;

    var resetButton = document.getElementById("reset");
    resetButton.onclick = formReset;

    var list_player = [];
    var count = 0;

    function addPlayer(){
        var name_input = document.getElementById("name");
        var age_input = document.getElementById("age");
        var feet_input = document.getElementById("feet");
        var inch_input = document.getElementById("inch");
        var gender_input = document.getElementById("gender");
        var class_input = document.getElementById("class");
        var weapon_input = document.getElementById("weapon");

        var name = name_input.value;
        var age = age_input.value;
        var feet = feet_input.value;
        var inch = inch_input.value;
        var gender = gender_input.value;
        var class_type = class_input.value;
        var weapon = weapon_input.value;

        feet = feet.toString();
        inch = inch.toString();

        if( name_input == false|| 
            age_input == false || 
            feet_input == false|| 
            inch_input == false|| 
            gender_input == false||
            class_input == false ||
            weapon_input == false ){

            alert("Something in your form is empty.")
        }
        else{
            list_player[count] = new create(name, age, feet, inch, gender, class_type, weapon);
            count++;
        }
    }

    function create(name, age, feet, inch, gender, class_type, weapon){
        this.name = name;
        this.age = age;
        this.height = feet + "'" + inch;
        this.gender = gender;
        this.class_type = class_type;
        this.weapon = weapon;

        alert("Player Created");
    }

    function display(){
        var table = document.getElementById("table");

        for(var x = 0; x < list_player.length; x++){
            if( x < 1){
                var tr = document.createElement("tr");

                var th_1 = document.createElement("th");
                var name = document.createTextNode("Name");
                th_1.appendChild(name);

                var th_2 = document.createElement("th");
                var age = document.createTextNode("Age");
                th_2.appendChild(age);

                var th_3 = document.createElement("th");
                var height = document.createTextNode("Height");
                th_3.appendChild(height);

                var th_4 = document.createElement("th");
                var gender = document.createTextNode("Gender");
                th_4.appendChild(gender);

                var th_5 = document.createElement("th");
                var class_type = document.createTextNode("Class");
                th_5.appendChild(class_type);

                var th_6 = document.createElement("th");
                var weapon = document.createTextNode("Weapon");
                th_6.appendChild(weapon);

                tr.appendChild(th_1);
                tr.appendChild(th_2);
                tr.appendChild(th_3);
                tr.appendChild(th_4);
                tr.appendChild(th_5);
                tr.appendChild(th_6);
                table.appendChild(tr);
  
            }
            var tr = document.createElement("tr");
            
            var td_1 = document.createElement("td");
            var name = document.createTextNode(list_player[x].name);
            td_1.appendChild(name);

            var td_2 = document.createElement("td");
            var age = document.createTextNode(list_player[x].age);
            td_2.appendChild(age);

            var td_3 = document.createElement("td");
            var height = document.createTextNode(list_player[x].height);
            td_3.appendChild(height);

            var td_4 = document.createElement("td");
            var gender = document.createTextNode(list_player[x].gender);
            td_4.appendChild(gender);

            var td_5 = document.createElement("td");
            var class_type = document.createTextNode(list_player[x].class_type);
            td_5.appendChild(class_type);

            var td_6 = document.createElement("td");
            var weapon = document.createTextNode(list_player[x].weapon);
            td_6.appendChild(weapon);

            tr.appendChild(td_1);
            tr.appendChild(td_2);
            tr.appendChild(td_3);
            tr.appendChild(td_4);
            tr.appendChild(td_5);
            tr.appendChild(td_6);
            table.appendChild(tr);
        }
    }

}
function formReset(){
    document.getElementById("name").value = "";
    document.getElementById("age").value = "";
    document.getElementById("feet").value = "";
    document.getElementById("inch").value = "";
    document.getElementById("class").value = "";
    document.getElementById("weapon").value = "";
}