window.onload = go;
var map;

function go(){
	if(navigator.geolocation)
		navigator.geolocation.getCurrentPosition(displayLocation);
	else
		alert("No geolocation supported");
}

function displayLocation(position) {
	var lat = position.coords.latitude;
	var lng = position.coords.longitude;

	for(var i = 0; i < myData.length;i++){
		showMap(myData[i]);
	}

	var googleLatAndLong = new google.maps.LatLng(lat,lng);
	addMarker(map,googleLatAndLong,"your location", "here");
}


function showMap(coords) {
	var iData = coords;
	var googleLatAndLong = new google.maps.LatLng(iData.lat,iData.lng);

	var options ={
		zoom: 7,
		center: googleLatAndLong,
		mapType: google.maps.MapTypeId.HYBRID
	};

	var div = document.getElementById("map");
	map = new google.maps.Map(div,options);

	addMarker(map,googleLatAndLong,iData.desc,iData.desc);
}

function addMarker(map, latlong, title, content) {
	var options = {
		position: latlong,
		map:map,
		title:title,
		clickable: true
	};

	var marker = new google.maps.Marker(options);

	var infoOptions = {
		content: content,
		position: latlong
	};

	var infoWindow = new google.maps.infoWindow(infoOptions);

	google.maps.event.addListener(marker, "click", function() {
		infoWindow.open(map);
	});
}

var myData = [	{"lat":31.621139,"lng":-94.649997, "desc":"On SFA Campus"},
				{"lat":31.629763,"lng":-94.652121, "desc":"Nacogdoches North Street"},
				{"lat":31.313036,"lng":-94.724320, "desc":"Lufkin Mall"},
				{"lat":31.310495, "lng":-94.724244, "desc":"Lufkin Loop"},
				{"lat":32.315345, "lng":-95.250946, "desc":"Tyler Location"}];